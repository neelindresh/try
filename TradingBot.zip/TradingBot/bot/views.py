# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render
import os
#import Libraries
import pandas_datareader.data as web
import datetime

def login(request):
    return render(request,"login.html")
def index(request):
    alldata={"data":-1,"label":-1,"upper":-1,"lower":-1,"bandwidth":-1,"movingAverage":-1,"ticker":-1,"dailyreturn":-1,"MACD":-1,"signal":-1,"operation":-1}
    if request.POST:
        sd=request.POST["startDate"].split("-")
        ed=request.POST["endDate"].split("-")
        ticker=request.POST["tickerName"]
        #window=int(request.POST["window"])
        window=20
        operation=request.POST["indicator"]
        start_date=datetime.date(int(sd[0]),int(sd[1]),int(sd[2]))
        end_date=datetime.date(int(ed[0]),int(ed[1]),int(ed[2]))
        data=web.get_data_yahoo(ticker,start_date,end_date)
        df=getBolingerBands(data,window)
        df=getDailyReturn(df)
        df=MACD(df)
        df["BandWidth"]=df["upperBand"]-df["lowerBand"]
        alldata={"label":[str(i.date()) for i in data.index],
        "data":list(data["Adj Close"].values),
        "upper":list(df["upperBand"].fillna(data["Adj Close"][:window].mean()).values),
        "lower": list(df["lowerBand"].fillna(data["Adj Close"][:window].mean()).values),
        "bandwidth": list(df["BandWidth"].fillna(0).values),
        "movingAverage":list(df["MovingAverage"].fillna(data["Adj Close"][:window].mean()).values),
        "ticker":[ticker],
        "dailyreturn":list(df["%change"].fillna(0).values),
        "MACD":list(df["MACD"].fillna(0).values),
        "signal":list(df["signal"].fillna(0).values),
        "operation":operation}
    return render(request,"index.html",alldata)


def getBolingerBands(df,n):
    df["MovingAverage"]=df["Adj Close"].rolling(n).mean()
    df["MovingStd"]=df["Adj Close"].rolling(n).std()
    df["upperBand"]=df["MovingAverage"]+(df["MovingStd"]*2)
    df["lowerBand"]=df["MovingAverage"]-(df["MovingStd"]*2)
    df.drop("MovingStd",inplace=True,axis=1)
    return df
def getDailyReturn(data):
    data["%change"]=data["Adj Close"].pct_change()*100
    return data
def MACD(data,fast=12,slow=26,signal=9):
    data["MA_Fast"]=data["Adj Close"].ewm(span=fast, min_periods=fast).mean()
    data["MA_Slow"]=data["Adj Close"].ewm(span=slow, min_periods=slow).mean()
    data["MACD"]=data["MA_Fast"]-data["MA_Slow"]
    data["signal"]=data["MACD"].ewm(span=signal,min_periods=signal).mean()
    data.drop(["MA_Fast","MA_Slow"],axis=1,inplace=True)
    return data
