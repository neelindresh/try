console.log("Hi I am connected");
var Something="hi all"
function drawLine(container_id,title,subtitle,y_label,x_label,series){
  //series=[{name: "name",data:[]},{name: "name",data:[]}]
  //x_label=[]
  Highcharts.chart(container_id, {

        title: {
            text: title
        },

        subtitle: {
            text: subtitle
        },
        xAxis: {
        categories: x_label
        },
        yAxis: {
            title: {
                text: y_label
            }
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle'
        },

        plotOptions: {
            series: {
                label: {
                    connectorAllowed: false
                },

            }
        },

        series: series,

        responsive: {
            rules: [{
                condition: {
                    maxWidth: 500
                },
                chartOptions: {
                    legend: {
                        layout: 'horizontal',
                        align: 'center',
                        verticalAlign: 'bottom'
                    }
                }
            }]
        }

      });
}
